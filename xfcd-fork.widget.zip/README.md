# xkcd-fork.widget

## Screenshot
![xkcd-fork.widget-Screenshot](./screenshot.png)

## Description
Übersicht widget to shows the latest xkcd comic and alt text.
Made for [Übersicht](http://tracesof.net/uebersicht/)
Übersicht is awesome for your OSX desktop.

## Sources
Fork from : <a href="https://github.com/dalemanthei/uebersicht-widgets/tree/master/xkcd">dalemanthei/uebersicht-widgets/xkcd/ on Github</a>
Style based on DiskUsage-Bar-Widget : <a href="https://github.com/dinever/DiskUsage-Bar-Widget">Sources on Github</a>

